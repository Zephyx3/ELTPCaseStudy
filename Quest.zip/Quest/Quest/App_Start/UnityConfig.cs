using System.Web.Http;
using Unity;
using Unity.WebApi;
using QuestServiceLayer;
using Quest;
using Unity.Mvc5;
using System.Web.Mvc;

namespace Quest
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {   //Dependency Injections
			var container = new UnityContainer();
            container.RegisterType<IQuestionService, QuestionService>();
            container.RegisterType<IUsersService, UserService>();
            container.RegisterType<ICategoriesService, CategoriesService>();
            container.RegisterType<IAnswersService, AnswersService>();
            
            DependencyResolver.SetResolver(new Unity.Mvc5.UnityDependencyResolver(container));
            GlobalConfiguration.Configuration.DependencyResolver = new Unity.WebApi.UnityDependencyResolver(container);
            
            // register all your components with the container here
            // it is NOT necessary to register your controllers
            // e.g. container.RegisterType<ITestService, TestService>();
            //GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}