﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QuestViewModels;
using QuestServiceLayer;
using System.Net.Http;
//using System.Web.Http;

namespace Quest.Controllers
{

    public class HomeController : Controller
    {
        readonly IQuestionService qs;
        readonly ICategoriesService cs;
        //public HomeController(){}
        public HomeController(IQuestionService qs, ICategoriesService cs)
        {
            this.qs = qs;
            this.cs = cs;
        }
        // GET: Home
        
        
        public ActionResult Index()
        {
            //List<QuestionViewModel> questions = qs.GetQuestions().Take(2).ToList();
            List<QuestionViewModel> questions = this.qs.GetQuestions().ToList();

            return View(questions);
            //return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Contact()
        {

            return View();
        }
        public ActionResult Categories()
        {
            List<CategoryViewModel> categories = this.cs.GetCategories();
            return View(categories);
        }

        [Route("allquestions")]
        public ActionResult Questions()
        {
            List<QuestionViewModel> questions = this.qs.GetQuestions();
            return View(questions);
        }
        public ActionResult Search(string str)
        {
            //List<QuestionViewModel> questions = this.qs.GetQuestions().Where(temp => temp.QuestionName.ToLower().Contains(str.ToLower()) || temp.Category.CategoryName.ToLower().Contains(str.ToLower())).ToList();
            List<QuestionViewModel> questions = qs.GetQuestions().Where(temp => temp.QuestionName.ToLower().Contains(str.ToLower()) || temp.Category.CategoryName.ToLower().Contains(str.ToLower())).ToList();
            ViewBag.str = str;
            return View(questions);
        }
    }
}