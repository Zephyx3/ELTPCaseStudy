﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QuestServiceLayer;
using System.Net.Http;
using System.Web.Http;

namespace Quest.apicontrollers
{
    public class QuestionsController : ApiController
    {
        readonly IAnswersService asr;
        // GET: Questions

        public QuestionsController(IAnswersService asr)
        {
            this.asr = asr;
        }
        public void Post(int AnswerID, int UserID, int value)
        {
            this.asr.UpdateAnswerVotesCount(AnswerID, UserID, value);
        }
    }
}