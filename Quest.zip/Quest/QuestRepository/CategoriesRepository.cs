﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QuestDomainModel;

namespace QuestRepository
{
    public interface ICategoriesRepository
    {
        void insertCategory(Category c);
        void UpdateCategory(Category c);
        void DeleteCategory(int cid);
        List<Category> GetCategories();
        List<Category> GetCategoriesByCategoryID(int CategoryID);
        
    }
    public class CategoriesRepository : ICategoriesRepository
    {
        QuestDBContext db;
        public CategoriesRepository()
        {
            db = new QuestDBContext();
        }

        public void insertCategory(Category c)
        {
            db.Categories.Add(c);
            db.SaveChanges();
        }

        public void UpdateCategory(Category c)
        {
            Category ct = db.Categories.Where(temp => temp.CategoryID == c.CategoryID).FirstOrDefault();
            if(ct != null)
            {
                ct.CategoryName = c.CategoryName;
                db.SaveChanges();
            }
        }

        public void DeleteCategory(int cid)
        {
            Category ct = db.Categories.Where(temp => temp.CategoryID == cid).FirstOrDefault();
            if (ct != null)
            {
                db.Categories.Remove(ct);               
                db.SaveChanges();
            }
        }

        public List<Category> GetCategories()
        {
            List<Category> ct = db.Categories.ToList();
            return ct;
        }

        public List<Category> GetCategoriesByCategoryID(int CategoryID)
        {
            List<Category> ct = db.Categories.Where(temp => temp.CategoryID == CategoryID).ToList();
            return ct;
        }
    }
}
