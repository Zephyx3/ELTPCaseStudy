﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QuestDomainModel;

namespace QuestRepository
{
    public interface IVotesRepository
    {
        void UpdateVote(int aid, int uid, int value);
    }
    public class VotesRepository : IVotesRepository
    {
        QuestDBContext db;

        public VotesRepository()
        {
            db = new QuestDBContext();
        }

        public void UpdateVote(int aid, int uid, int value)
        {
            int updateValue = 0;
            if (value > 0)
            {
                updateValue = 1;
            }
            else if (value < 0)
            {
                updateValue = -1;
            }
            else
            {
                updateValue = 0;
            }

            Vote vote = db.Votes.Where(temp => temp.AnswerID == aid && temp.UserID == uid).FirstOrDefault();
            if (vote != null)
            {
                vote.VotesCount = updateValue;
            }
            else
            {
                Vote newVote = new Vote()
                {
                    AnswerID = aid,
                    UserID = uid,
                    VotesCount = updateValue
                };
                db.Votes.Add(newVote);
            }
            //new code below
            db.SaveChanges();
        }
    }
}
