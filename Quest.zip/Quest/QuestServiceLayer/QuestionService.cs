﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QuestViewModels;
using QuestRepository;
using QuestDomainModel;
using AutoMapper;
using AutoMapper.Configuration;

namespace QuestServiceLayer
{
    public interface IQuestionService
    {
        void InsertQuestion (NewQuestionViewModel qvm);
        void UpdateQuestionDetails(EditQuestionViewModel qvm);
        void UpdateQuestionAnswersCount(int qid, int value);
        void UpdateQuestionVotesCount(int qid, int value);
        void UpdateQuestionViewsCount(int qid, int value);
        void DeleteQuestion(int qid);


        List<QuestionViewModel> GetQuestions();
        QuestionViewModel GetQuestionByQuestionID(int QuestionID, int UserID);
        
    }
    public class QuestionService : IQuestionService
    {
        //Edited code to make qr null.
        //IQuestionRepository qr;
        readonly IQuestionRepository qr = null;

        public QuestionService()
        {
            qr = new QuestionsRepository();
        }
        public void DeleteQuestion(int qid)
        {
            qr.DeleteQuestion(qid);
        }

        public QuestionViewModel GetQuestionByQuestionID(int QuestionID, int UserID)
        {
            Question q = qr.GetQuestionsByQuestionID(QuestionID).FirstOrDefault();
            QuestionViewModel qvm = null;
            if(q != null)
            {
                //Mapper.CreateMap<Client, ClientViewModel>();
                //ClientViewModel cvm = Mapper.Map<Client, ClientViewModel>(client);

                var config = new MapperConfiguration(cfg => { cfg.CreateMap<Question, QuestionViewModel>(); cfg.IgnoreUnmapped(); });
                IMapper mapper = config.CreateMapper();
                
                qvm = mapper.Map<Question, QuestionViewModel>(q);
                foreach(var item in qvm.Answers)
                {
                    item.CurrentUserVoteType = 0;
                    VotesViewModel vote = item.Votes.Where(temp => temp.UserID == UserID).FirstOrDefault();
                    if(vote != null)
                    {
                        item.CurrentUserVoteType = vote.VoteValue;
                    }
                }
            }
            return qvm;
        }

        public List<QuestionViewModel> GetQuestions()
        {
            List<Question> q = qr.GetQuestions();
            var config = new MapperConfiguration(cfg => { cfg.CreateMap<Question, QuestionViewModel>(); cfg.IgnoreUnmapped();});
            IMapper mapper = config.CreateMapper();

            List<QuestionViewModel> qvm = mapper.Map<List<Question>, List<QuestionViewModel>>(q);
            return qvm;
        }

        public void InsertQuestion(NewQuestionViewModel qvm)
        {
            var config = new MapperConfiguration(cfg => { cfg.CreateMap<NewQuestionViewModel, Question>(); cfg.IgnoreUnmapped(); });
            IMapper mapper = config.CreateMapper();
            Question q = mapper.Map<NewQuestionViewModel, Question>(qvm);
            qr.InsertQuestion(q);
        }

        public void UpdateQuestionAnswersCount(int qid, int value)
        {
            qr.UpdateQuestionAnswersCount(qid, value);
        }
        public void UpdateQuestionDetails(EditQuestionViewModel qvm)
        {
            var config = new MapperConfiguration(cfg => { cfg.CreateMap<EditQuestionViewModel, Question>(); cfg.IgnoreUnmapped(); });
            IMapper mapper = config.CreateMapper();
            Question q = mapper.Map<EditQuestionViewModel, Question>(qvm);
            qr.UpdateQuestionDetails(q);
        }

        public void UpdateQuestionViewsCount(int qid, int value)
        {
            qr.UpdateQuestionViewsCount(qid, value);
        }

        public void UpdateQuestionVotesCount(int qid, int value)
        {
            qr.UpdateQuestionVotesCount(qid, value);
        }
    }
}
